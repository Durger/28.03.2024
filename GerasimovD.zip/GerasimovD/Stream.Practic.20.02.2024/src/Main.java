import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


public class Main {
    //Метод генерации случайных чисел
    private static  int [] generationRandomNumber (int count) {
        int[] numbers = new int[count];
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            numbers[i] = random.nextInt();
        }
        return numbers;
    }

        public static void main(String[] args) {

        //Задача.1
        // Для набора случайно сгенерированных целых чисел нужно:
        //■ Количество четных;
        //■ Количество нечетных;
        //■ Количество равных 0;
        //■ Количество равных значению, введенному пользователем.

       //int [] numbers = generationRandomNumber(100);

       List <Integer> numbers = new ArrayList<>();
       Random random1 = new Random();
            for (int i = 0; i < 10; i++){
                numbers.add((random1.nextInt(100)));
            }

            //■ Количество четных;
            int countEven = (int)numbers.stream().filter(f->f%2==0).count();
            int NonCountEven = (int)numbers.stream().filter(f->f%2!=0).count();
            int zeroCount = (int)numbers.stream().filter(f->f==0).count();
            Scanner scanUser = new Scanner("Введите число: ");
            int numberClient = scanUser.nextInt();
            int clientCountEven = (int)numbers.stream().filter(f->f == numberClient).count();
            System.out.println("Колличество счетных чисел пользователя: " + clientCountEven);


        }
    }
