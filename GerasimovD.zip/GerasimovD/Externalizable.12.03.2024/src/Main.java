import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        //
        FileOutputStream fileOutputStream = new FileOutputStream("text.txt");
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        UserInfo userInfo = new UserInfo("Ivan", "Ivanov", "Ivan Ivanov pasport data");
        objectOutputStream.writeObject(userInfo);
        objectOutputStream.close();

        FileInputStream fileInputStream = new FileInputStream("text.txt");
        ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);
        UserInfo userInfo1 = (UserInfo)inputStream.readObject();
        System.out.println(userInfo1);
        inputStream.close();

    }
}