import java.io.*;

public class Main {

    //Сериализация
    public static void serialize (Object obj, String fileName) {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(obj);
            fos.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: ");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Input/Output error: ");
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                System.err.println("Input/Output error: ");
                e.printStackTrace();
            }
        }
    }

    //Десериализация
    public static Object derialize (String fileName) {
        FileInputStream fis = null;
        Object obj = null;
        try {
            fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            obj = ois.readObject();
            ois.read();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: ");
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("Input/Output error: ");
            e.printStackTrace();
        }
        catch (ClassNotFoundException e){
            System.err.println("Class not found: ");
            e.printStackTrace();
        }
        finally {
            try {
               fis.close();
            } catch (IOException e) {
                System.err.println("Input/Output error: ");
                e.printStackTrace();
            }
        }
        return obj;
    }

    public static void main(String[] args) {
        Fish fish = new Fish("Salmon",200,2.5);
        serialize (fish, "fish.txt");
        Fish fish1 = (Fish) derialize("fish.txt");
        System.out.println(fish1);
    }
}

class Fish implements Serializable{
    String name;
    double price;
    double weight;

    //Конструктор
    public Fish(String name, double price, double weight){
       this.name = name;
       this.price = price;
       this.weight = weight;
    }
    public String getName(){
        return this.name;
    }
    public double getPrice(){
        return this.price;
    }
    public double getWeight(){
        return this.weight;
    }
    public String toString(){
        return "Name: " + this.name + "Price: " +  this.price + "Weight: " + this.weight;
    }


}