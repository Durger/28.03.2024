public class Theory {
/*
    int i = 0;

    //счётчик
    int count = 0;

//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");
//        count = count + 1;
//        System.out.println("Текущее значение счетчика: " + count + ", ");

    //цикл while
//        while (i < 60) {
//            count = count + 1;
//            System.out.println("Текущее значение счетчика: " + count + ", ");
//
//            i = i + 1;
//        }

//        //цикл while do
//        do {
//            count = count + 1;
//            System.out.println("Текущее значение счетчика: " + count + ", ");
//            i = i + 1;
//        }
//        while (i < 25);

    //цикл for
//        for (int x = 0; x < 25; x=x+1) {
//            count = count + 1;
//            System.out.println("Текущее значение счетчика: " + count + ", ");
//        }

    int [] numbers = new int[] {3, 2, 1, 0, -1};
        for (int number : numbers) {
        number = number + 10;
        if (i == 3) {
            System.out.println("Сейчас значение i = " + i);
        }
        i = i + 1;
        System.out.println(number);
//            System.out.println("Сейчас значение i = " + i);

/*
 */

}
