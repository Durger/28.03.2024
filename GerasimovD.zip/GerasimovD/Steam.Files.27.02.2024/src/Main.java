import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        //Пример.1.
        /* String fileName = "test.txt ";
        String fullName = "";
        String dirName = System.getProperty("user.dir");
        fullName = dirName + File.separator+fileName;
        String dirname = dirName + "/tmp/user/java/bin";
        File d = new File(dirname);
        d.mkdirs();
        System.out.println("File path: " + fullName);
        File file = new File(fullName);
        if (!file.exists()) {
            try {
                if (file.createNewFile()){
                    System.out.println("file created!");
                } else {
                    System.out.println("Something Wrong!");
                }
            } catch (IOException e ) {
                Logger.getLogger(File.class.getName()).log(Level.SEVERE,null,e);
            }
        } else {
            System.out.println("File already exists!");
        }*/

        //Пример.2.
        /*InputStream in = null;
        OutputStream out = null;
        byte [] buffer = null;
        try {
            in = new FileInputStream(new File("test.txt"));
            buffer = new byte [in.available()];
            in.read(buffer);
            File file = new File ("outputFile.txt");
            out = new FileOutputStream(file);
            out.write(buffer);
        } catch(FileNotFoundException e){
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        }catch (IOException e){
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        }finally {
         try{
             in.close();
             out.close();
        }
        catch (IOException e){
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        }
        }*/


        //Пример.3.
        /*InputStream in = null;
        OutputStream out = null;
        byte [] buffer = new byte[8*1024];
        try{
            in = new FileInputStream(new File("2.txt"));
            File file = new File("outFile1.tmp");
            out = new FileOutputStream(file);
            int byteRead = 0;
            while ((byteRead = in.read(buffer))!= -1){
                out.write(buffer,0, byteRead);
            }
        }
        catch (FileNotFoundException e){
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }
        catch (IOException e){
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }
        finally {
            try{
                in.close();
                out.close();
            }
            catch (IOException e){
                Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
            }
        }*/

        //Пример.4.Метод Read, побайтовый поиск символа
        /*FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream(new File("test.txt"));
            File file = new File("outFile3.txt");
            out = new FileOutputStream(file);
            int c;
            while ((c = in.read())!= -1){
                if (c < 65)out.write(c);
            }
        }
        catch (FileNotFoundException e){
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }
        catch (IOException e){
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }
        finally {
            try{
                in.close();
                out.close();
            }
            catch (IOException e){
                Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
            }*/


            //Пример.5. Byte Array Stream
        OutputStream out = null;
        File file = new File("2.jpg");
        File file2 = new File ("outputFile2.txt");

            try{
                BufferedImage bufferImage = ImageIO.read(file);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ImageIO.write(bufferImage, "jpg", byteArrayOutputStream);
                byte [] imageInByte = byteArrayOutputStream.toByteArray();

                out = new FileOutputStream(file2);
                out.write(imageInByte);
            }
            catch (IOException e){
                Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
            }

        }


    }

