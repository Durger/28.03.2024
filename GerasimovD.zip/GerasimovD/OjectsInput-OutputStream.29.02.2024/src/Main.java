import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.awt.Color.white;
import static java.awt.SystemColor.text;

public class Main {
    public static void main(String[] args) {
//Пример/1
        FileOutputStream fout = null;            // поток для работы с объектами
        ObjectOutputStream oout = null;          // поток для работы с файлами
        try {
            fout = new FileOutputStream("test.txt");
            Fish f = new Fish("salmon", 2.5, 200);
            //f.showFish();
            oout = new ObjectOutputStream(fout);
            oout.writeObject(f);

        } catch (FileNotFoundException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } catch (IOException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                oout.close();
            } catch (IOException e) {
                Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        FileInputStream fin = null; //вход в поток
        try {
            fin = new FileInputStream(new File("test.txt"));
            ObjectInputStream oin = new ObjectInputStream(fin);
            Fish f1 = (Fish) oin.readObject();
            System.out.println(f1);
        } catch (FileNotFoundException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } catch (IOException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } catch (ClassNotFoundException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                fin.close();
            } catch (IOException e) {
                Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
            }
        }
        //Задача с машиной
        FileOutputStream carFileStream = null;
        ObjectOutputStream carObjectStream = null;
        try {
            carFileStream = new FileOutputStream("car.txt");
            Car l = new Car("Lambo", 4.5, 2000);
            oout = new ObjectOutputStream(carFileStream);
            oout.writeObject(l);

        } catch (FileNotFoundException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } catch (IOException e) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                oout.close();
            } catch (IOException e) {
                Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, e);
            }
        }

        //Пример.2. работа с буфером
        //r - курсор в начало
        //n - новая строка
        //t - перенос на 4 знака TAB
        String text = "String test\r\n" + "in file\r\n" + "hello r\n";
        try (FileOutputStream out = new FileOutputStream("test3.txt");
        BufferedOutputStream bos = new BufferedOutputStream(out)){
            byte[]buffer = text.getBytes();
            bos.write(buffer, 0, buffer.length); // буфер, начальное значение, конечное значение
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }
        try (FileInputStream fin1 = new FileInputStream(new File("test3.txt"));
             BufferedInputStream bufferedOutputStream = new BufferedInputStream(fin1)) {
            int c;
            while ((c=bufferedOutputStream.read())!=-1) {
                System.out.print((char)c);
            }
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
    //класс с наследованием от класса Serializable
    class Fish implements Serializable {
        String name;
        double price;
        double weight;

        public Fish(String name, double price, double weight) {
            this.name = name;
            this.price = price;
            this.weight = weight;
        }

        public String getName() {
            return this.name;
        }

        public double getPrice() {
            return this.price;
        }

        public double getWeight() {
            return this.weight;
        }
        @Override
        public String toString (){
            return "Name: " + this.name + "Price: " + this.price + "Weight: " + this.weight;

        }
       /* public void showFish() {
            System.out.printf("Name: " + this.name + "Price: " + this.price + "Weight: " + this.weight);
        }*/
    }




    //Создать класс автомобиль (в нем цвет,объем двигателя, год выпуска),
    //Создать файл для записи в него, потом достать из файла объект и вывести его в консоль
class Car implements Serializable{
    String color;
    double volumeEngine;
    double dateOfCreated;

    public Car(String color, double volumeEngine, double dateOfCreated) {
        this.color = color;
        this.volumeEngine = volumeEngine;
        this.dateOfCreated = dateOfCreated;
    }

    @Override
    public String toString() {
        return "Color: " + this.color + " Volume: " + this.volumeEngine + "Date of created: " + this.dateOfCreated;
    }
}