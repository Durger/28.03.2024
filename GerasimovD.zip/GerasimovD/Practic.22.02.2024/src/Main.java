import java.sql.Array;
import java.util.*;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    //1
    /*private static  <T> Collection <T> removeDublicate(Collection<T>collection){
    return  new HashSet<>(collection);
    }*/

    //2
   /* private static void compare2List(){
       ArrayList <Double> arrayList = new ArrayList<>();
        LinkedList <Double> linked = new LinkedList<>();
        final int N = 100000;
        final int M = 100;
        for(int i = 0; i < N; i++){
            arrayList.add(Math.random());
            linked.add(Math.random());
        }
        long startTime = System.currentTimeMillis();
        for(int i = 0; i < M; i++){
            arrayList.get((int)(Math.random()*(N-1)));
        }
        System.out.println(System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();
        for(int i = 0; i < M; i++){
            linked.get((int)(Math.random()*(N-1)));
        }
        System.out.println(System.currentTimeMillis() - startTime);
    }*/

    public static void main(String[] args) {
// задание1:
//Напишите метод, который на вход получает коллекцию объектов, а возвращает коллекцию уже без дубликатов.

        /*Collection <String> removeDublicate = new ArrayList<>();
        removeDublicate.add("Argentina");
        removeDublicate.add("Bulgaria");
        removeDublicate.add("Canada");
        removeDublicate.add("Denmark");
        removeDublicate.add("Denmark");
        System.out.println("Colection: " + removeDublicate);
        Collection <String> unicalCollection = removeDublicate(removeDublicate);
       for(String ele : unicalCollection){
           System.out.println(ele);
        }*/

//задание2:
//Напишите метод, который добавляет 1000000 элементов в ArrayList и LinkedList. Напишите еще один метод,
// который выбирает из заполненного списка элемент наугад 100000 раз. Замерьте время, которое потрачено на это.
// Сравните результаты и предположите, почему они именно такие.

       /* compare2List();*/

//задание 3:
//Написать итератор по массиву

       /*Integer [] array = {1,2,3,4,5};
       ArrayIterator <Integer> iterator = new ArrayIterator<>(array);
       while ((iterator.hasNext())){
           Integer element = iterator.next();
           System.out.println(element);
       }*/

//задание 4:
//Напишите итератор по двумерному массиву.

        Integer[][] integers = {
               {1,2,3},
               {6,7,8},
               {1,1,1}
        };
       Array2d <Integer> integers1 = new Array2d<>(integers);
       for (Integer integer : integers1){
           System.out.println(integer);
       }


//задание 5:
//Дан итератор. Метод next() возвращает либо String, либо итератор такой же структуры (то есть который опять возвращает или String, или такой же итератор). Напишите поверх этого итератора другой, уже «плоский».
//однорешение рекурсиное второе на стеках

       List <Object> list1 = new ArrayList<>();
       list1.add("Hello");
       list1.add("world");

        List <Object> list2 = new ArrayList<>();
        list2.add(123);
        list2.add(456);

        List <Object> list3 = new ArrayList<>();
        list3.add("Java");
        list3.add("codding");

        List <Object> mainList = new ArrayList<>();
        mainList.add(list1.iterator());
        mainList.add(list2.iterator());
        mainList.add(list3.iterator());

        DeeepIterator deeepIterator = new DeeepIterator(mainList.listIterator());
        while (deeepIterator.hasNext()){
            String elements = deeepIterator.next();
            System.out.println(elements);
        }






//задание 6:
//Напишите итератор, который проходит по двум итератором.

//задача 7:
//Напишите метод, который получает на вход массив элементов типа К (Generic) и возвращает Map<K, Integer>, где K — значение из массива, а Integer — количество вхождений в массив.
//То есть сигнатура метода выглядит так:

        }
    }

    //4
/*class Array2d <T> implements Iterable <T> {
    private  T[][] array;
    public  Array2d (T[][] array){
        this.array = array;
    }

    @Override
    public Iterator <T> iterator() {
        return new Iterator <T> () {
            private int i, j;

            @Override
            public boolean hasNext() {
                for (int i = 0; i < array.length; i++) {
                    for (int j = this.j; j < array[i].length; j++) {
                        return true;
                    }
                }
                return false;
            }

                @Override
                public T next() {
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }
                    T t = array [i][j];
                    j++;
                    for (int i = this.i; i < array.length; i++){
                        for (int j = (i==this.i?this.j:0); j < array[i].length; j++) {
                            this.i = i;
                            this.j = j;
                        }
                    }
                    return t;

                }


        };
    }
}*/


//3
   /* class ArrayIterator <T> implements Iterator <T> {
        private T[] array;
        private int index = 0;

        public ArrayIterator(T[] array) {
            this.array = array;
        }

        @Override
        public boolean hasNext() {
            return index < array.length;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return array[index++];
        }
    }*/

//5
class DeeepIterator implements Iterator<String>{

    private  Stack <Iterator> iterators;
    private  String next;
    private boolean hasNext;
    public  DeeepIterator (Iterator <?> iterator){
        this.iterators = new Stack<Iterator>();
        iterators.push(iterator);
        updateNext();

    }
    @Override
    public boolean hasNext() {
        return hasNext;
    }

    private void updateNext(){
        if (iterators.empty()) {
            next = null;
            hasNext = false;
            return;
        }
        Iterator current = iterators.peek();
        if(current.hasNext()){
            Object o = current.next();
            if (o instanceof String){
                next = (String) o;
                hasNext = true;
            }
            else if (o instanceof Iterator){
                Iterator iterator = (Iterator) o;
                iterators.push(iterator);
                updateNext();
                }
            else {
                throw new IllegalArgumentException();
            }
            else {
                iterators.pop();
                updateNext();
            }
        }
    }

    @Override
    public String next() {
        if(!hasNext()){
            throw new NoSuchElementException();

        }
        String nextToReturn = next;
        updateNext();
        return nextToReturn;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}




